module aula10.ex1 {
	requires static lombok;
	requires org.apache.logging.log4j;
	requires java.desktop;
	requires java.sql;
	requires org.mariadb.jdbc;
}