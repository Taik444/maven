package aula10.ex1.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

import aula10.ex1.model.BoletimModel;
import aula10.ex1.model.TipoDeProva;

/**
 * 
 * VISÃO - tela de cadastro de tipos de prova (P1, P2, Substitutiva, Exame...).
 *
 * A visão só sabe DESENHAR a tela e EXPOR seus componentes. Ela não grava
 * nada no banco e não decide o que fazer quando um botão é clicado: isso é
 * papel do TipoDeProvaController. Ela é OBSERVADORA do modelo: quando o
 * BoletimModel avisa que os tipos de prova mudaram, a tabela é redesenhada.
 * 
 */

public class PainelTiposDeProva extends JPanel implements PropertyChangeListener {

    private static final long serialVersionUID = 1L;
    private final JTextField txtNome = new JTextField(30);
    private final JButton btnCadastrar = new JButton("Cadastrar");
    private final JButton btnAtualizar = new JButton("Atualizar");
    private final JButton btnExcluir = new JButton("Excluir");
    private final JButton btnDesselecionar = new JButton("Desselecionar");

    private final DefaultTableModel tabelaModelo = new DefaultTableModel(new Object[] { "ID", "Tipo de Prova" }, 0) {
    	private static final long serialVersionUID = 1L;

        @Override
        public boolean isCellEditable(int linha, int coluna) {
        	return false;
        }
	};

    private final JTable tabela = new JTable(tabelaModelo);
    private List<TipoDeProva> exibidos = new ArrayList<>();
    private int idEmEdicao = 0;   // 0 = novo tipo de prova

    public PainelTiposDeProva() {
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel formulario = new JPanel(new FlowLayout(FlowLayout.LEFT));
        formulario.add(new JLabel("Tipo de Prova:"));
        formulario.add(txtNome);

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnDesselecionar.setVisible(false);
        botoes.add(btnDesselecionar);
        botoes.add(btnCadastrar);
        botoes.add(btnAtualizar);
        botoes.add(btnExcluir);

        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.getColumnModel().getColumn(0).setMaxWidth(80);

        add(formulario, BorderLayout.NORTH);
        add(new JScrollPane(tabela), BorderLayout.CENTER);
        add(botoes, BorderLayout.SOUTH);

        // Ao selecionar uma linha, preenche o formulário para edição
        tabela.getSelectionModel().addListSelectionListener(e -> {

        	if (e.getValueIsAdjusting()) {
                return;
            }

            int linha = tabela.getSelectedRow();

            if (linha >= 0 && linha < exibidos.size()) {

                TipoDeProva tipo = exibidos.get(linha);
                idEmEdicao = tipo.getIdTipoDeProva();
                txtNome.setText(tipo.getTipoDeProva());

                btnDesselecionar.setVisible(true);

            } else {

                btnDesselecionar.setVisible(false);

            }

        });
    }

    // OBSERVADORA do modelo
    @Override
    @SuppressWarnings("unchecked")
    public void propertyChange(PropertyChangeEvent evt) {
        if (BoletimModel.TIPOS_DE_PROVA.equals(evt.getPropertyName())) {
            exibidos = new ArrayList<>((List<TipoDeProva>) evt.getNewValue());
            tabelaModelo.setRowCount(0);

            for (TipoDeProva tipo : exibidos) {
                tabelaModelo.addRow(new Object[] { tipo.getIdTipoDeProva(), tipo.getTipoDeProva() });
            }
        }
    }

    // Dados digitados
    public int getIdEmEdicao() {
        return idEmEdicao;
    }

    public String getNome() {
        return txtNome.getText();
    }

    // Ações da tela
    public void limparFormulario() {
        idEmEdicao = 0;
        txtNome.setText("");
        tabela.clearSelection();
        btnDesselecionar.setVisible(false);
        txtNome.requestFocusInWindow();
    }

    public void addDesselecionarListener(ActionListener l) {
        btnDesselecionar.addActionListener(l);
    }

    public void mostrarAviso(String mensagem) {
        JOptionPane.showMessageDialog(this, mensagem, "Atenção", JOptionPane.WARNING_MESSAGE);
    }

    public void mostrarErro(String mensagem) {
        JOptionPane.showMessageDialog(this, mensagem, "Erro", JOptionPane.ERROR_MESSAGE);
    }

    public boolean confirmar(String pergunta) {
        return JOptionPane.showConfirmDialog(this, pergunta, "Confirmação", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }

    // Ligação com o controlador
    public void addCadastrarListener(ActionListener l) { btnCadastrar.addActionListener(l); }
    public void addAtualizarListener(ActionListener l) { btnAtualizar.addActionListener(l); }
    public void addExcluirListener(ActionListener l) { btnExcluir.addActionListener(l); }
}
