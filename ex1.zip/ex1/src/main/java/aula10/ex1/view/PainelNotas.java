package aula10.ex1.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

import aula10.ex1.model.Aluno;
import aula10.ex1.model.BoletimModel;
import aula10.ex1.model.Disciplina;
import aula10.ex1.model.Nota;
import aula10.ex1.model.TipoDeProva;

/**
 * 
 * VISÃO - tela de lançamento de notas.
 * Observa o modelo: atualiza a tabela quando "notas" muda e as listas
 * suspensas (combos) quando "disciplinas", "tiposDeProva" ou "alunos" mudam.
 * 
 */

public class PainelNotas extends JPanel implements PropertyChangeListener {

    private static final long serialVersionUID = 1L;
    private final JComboBox<Disciplina> cmbDisciplina = new JComboBox<>();
    private final JComboBox<TipoDeProva> cmbTipoDeProva = new JComboBox<>();
    private final JComboBox<Aluno> cmbAluno = new JComboBox<>();
    private final JTextField txtNota = new JTextField(6);
    private final JButton btnCadastrar = new JButton("Cadastrar");
    private final JButton btnAtualizar = new JButton("Atualizar");
    private final JButton btnExcluir = new JButton("Excluir");
    private final JButton btnDesselecionar = new JButton("Desselecionar");

    private final DefaultTableModel tabelaModelo = new DefaultTableModel(new Object[] { "ID", "Disciplina", "Tipo de Prova", "Aluno", "Nota" }, 0) {
    	private static final long serialVersionUID = 1L;

        @Override
        public boolean isCellEditable(int linha, int coluna) {
        	return false;
        }
    };

    private final JTable tabela = new JTable(tabelaModelo);
    private List<Nota> exibidas = new ArrayList<>();
    private int idEmEdicao = 0;   // 0 = nova nota

    public PainelNotas() {
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel formulario = new JPanel(new FlowLayout(FlowLayout.LEFT));
        formulario.add(new JLabel("Disciplina:"));
        formulario.add(cmbDisciplina);
        formulario.add(new JLabel("Tipo de Prova:"));
        formulario.add(cmbTipoDeProva);
        formulario.add(new JLabel("Aluno:"));
        formulario.add(cmbAluno);
        formulario.add(new JLabel("Nota:"));
        formulario.add(txtNota);

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnDesselecionar.setVisible(false);
        botoes.add(btnDesselecionar);
        botoes.add(btnCadastrar);
        botoes.add(btnAtualizar);
        botoes.add(btnExcluir);

        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.getColumnModel().getColumn(0).setMaxWidth(60);

        add(formulario, BorderLayout.NORTH);
        add(new JScrollPane(tabela), BorderLayout.CENTER);
        add(botoes, BorderLayout.SOUTH);

        // Ao selecionar uma linha, preenche o formulário para edição
        tabela.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) {
                return;
            }
            int linha = tabela.getSelectedRow();
            if (linha >= 0 && linha < exibidas.size()) {
                Nota n = exibidas.get(linha);
                idEmEdicao = n.getIdNota();
                txtNota.setText(n.getNota().toPlainString());
                selecionarDisciplina(n.getDisciplina().getIdDisciplina());
                selecionarTipoDeProva(n.getTipoDeProva().getIdTipoDeProva());
                selecionarAluno(n.getAluno().getIdAluno());

                btnDesselecionar.setVisible(true);
            } else {
                btnDesselecionar.setVisible(false);
            }
        });

    }

    // OBSERVADORA do modelo
    @Override
    @SuppressWarnings("unchecked")
    public void propertyChange(PropertyChangeEvent evt) {
        String nome = evt.getPropertyName();

        if (BoletimModel.DISCIPLINAS.equals(nome)) {
            Disciplina anterior = getDisciplinaSelecionada();
            cmbDisciplina.removeAllItems();
            cmbDisciplina.addItem(new Disciplina(0, "Selecione..."));

            for (Disciplina d : (List<Disciplina>) evt.getNewValue()) {
                cmbDisciplina.addItem(d);
            }

            if (anterior != null && anterior.getIdDisciplina() != 0) {
                selecionarDisciplina(anterior.getIdDisciplina());
            } else {
            	cmbDisciplina.setSelectedIndex(0);
            }

        } else if (BoletimModel.TIPOS_DE_PROVA.equals(nome)) {
            TipoDeProva anterior = getTipoDeProvaSelecionado();
            cmbTipoDeProva.removeAllItems();
            cmbTipoDeProva.addItem(new TipoDeProva(0, "Selecione..."));

            for (TipoDeProva t : (List<TipoDeProva>) evt.getNewValue()) {
                cmbTipoDeProva.addItem(t);
            }

            if (anterior != null && anterior.getIdTipoDeProva() != 0) {
                selecionarTipoDeProva(anterior.getIdTipoDeProva());
            } else {
            	cmbTipoDeProva.setSelectedIndex(0);
            }

        } else if (BoletimModel.ALUNOS.equals(nome)) {
            Aluno anterior = getAlunoSelecionado();
            cmbAluno.removeAllItems();
            cmbAluno.addItem(new Aluno(0, "Selecione..."));

            for (Aluno a : (List<Aluno>) evt.getNewValue()) {
                cmbAluno.addItem(a);
            }

            if (anterior != null && anterior.getIdAluno() != 0) {
                selecionarAluno(anterior.getIdAluno());
            } else {
            	cmbAluno.setSelectedIndex(0);
            }

        } else if (BoletimModel.NOTAS.equals(nome)) {
            exibidas = new ArrayList<>((List<Nota>) evt.getNewValue());
            tabelaModelo.setRowCount(0);
            for (Nota n : exibidas) {
                tabelaModelo.addRow(new Object[] {
                        n.getIdNota(),
                        n.getDisciplina().getDisciplina(),
                        n.getTipoDeProva().getTipoDeProva(),
                        n.getAluno().getNomeDoAluno(),
                        n.getNota().toPlainString() });
            }
        }
    }

    private void selecionarDisciplina(int id) {
        for (int i = 0; i < cmbDisciplina.getItemCount(); i++) {
            if (cmbDisciplina.getItemAt(i).getIdDisciplina() == id) {
                cmbDisciplina.setSelectedIndex(i);
                return;
            }
        }
    }

    private void selecionarTipoDeProva(int id) {
        for (int i = 0; i < cmbTipoDeProva.getItemCount(); i++) {
            if (cmbTipoDeProva.getItemAt(i).getIdTipoDeProva() == id) {
                cmbTipoDeProva.setSelectedIndex(i);
                return;
            }
        }
    }

    private void selecionarAluno(int id) {
        for (int i = 0; i < cmbAluno.getItemCount(); i++) {
            if (cmbAluno.getItemAt(i).getIdAluno() == id) {
                cmbAluno.setSelectedIndex(i);
                return;
            }
        }
    }

    // Dados digitados
    public int getIdEmEdicao() { return idEmEdicao; }
    public String getNotaDigitada() { return txtNota.getText(); }
    public Disciplina getDisciplinaSelecionada() { return (Disciplina) cmbDisciplina.getSelectedItem(); }
    public TipoDeProva getTipoDeProvaSelecionado() { return (TipoDeProva) cmbTipoDeProva.getSelectedItem(); }
    public Aluno getAlunoSelecionado() { return (Aluno) cmbAluno.getSelectedItem(); }

    // Ações da tela
    public void limparFormulario() {
        idEmEdicao = 0;
        txtNota.setText("");
        if (cmbDisciplina.getItemCount() > 0) {
            cmbDisciplina.setSelectedIndex(0);
        }
        if (cmbTipoDeProva.getItemCount() > 0) {
            cmbTipoDeProva.setSelectedIndex(0);
        }
        if (cmbAluno.getItemCount() > 0) {
            cmbAluno.setSelectedIndex(0);
        }
        tabela.clearSelection();
        btnDesselecionar.setVisible(false);
        txtNota.requestFocusInWindow();
    }

    public void addDesselecionarListener(ActionListener l) {
        btnDesselecionar.addActionListener(l);
    }

    public void mostrarAviso(String mensagem) {
        JOptionPane.showMessageDialog(this, mensagem, "Atenção", JOptionPane.WARNING_MESSAGE);
    }

    public void mostrarErro(String mensagem) {
        JOptionPane.showMessageDialog(this, mensagem, "Erro", JOptionPane.ERROR_MESSAGE);
    }

    public boolean confirmar(String pergunta) {
        return JOptionPane.showConfirmDialog(this, pergunta, "Confirmação",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }

    // Ligação com o controlador
    public void addCadastrarListener(ActionListener l) { btnCadastrar.addActionListener(l); }
    public void addAtualizarListener(ActionListener l) { btnAtualizar.addActionListener(l); }
    public void addExcluirListener(ActionListener l) { btnExcluir.addActionListener(l); }
}
