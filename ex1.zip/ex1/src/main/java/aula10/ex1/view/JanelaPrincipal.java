package aula10.ex1.view;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;

/**
 * 
 * VISÃO - janela principal com uma aba para cada cadastro.
 * 
 */

public class JanelaPrincipal extends JFrame {

    private static final long serialVersionUID = 1L;
    private final PainelNotas painelNotas = new PainelNotas();
    private final PainelAlunos painelAlunos = new PainelAlunos();
    private final PainelDisciplinas painelDisciplinas = new PainelDisciplinas();
    private final PainelTiposDeProva painelTiposDeProva = new PainelTiposDeProva();

    public JanelaPrincipal() {
        super("Controle de Notas - Exemplo MVC");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        JTabbedPane abas = new JTabbedPane();
        abas.addTab("Notas", painelNotas);
        abas.addTab("Alunos", painelAlunos);
        abas.addTab("Disciplinas", painelDisciplinas);
        abas.addTab("Tipos de Prova", painelTiposDeProva);
        add(abas);
        setSize(1100, 600);
        setLocationRelativeTo(null);
    }

    public PainelNotas getPainelNotas() { return painelNotas; }
    public PainelAlunos getPainelAlunos() { return painelAlunos; }
    public PainelDisciplinas getPainelDisciplinas() { return painelDisciplinas; }
    public PainelTiposDeProva getPainelTiposDeProva() { return painelTiposDeProva; }
}
