package aula10.ex1.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import aula10.ex1.controller.AlunoController;
import aula10.ex1.controller.DisciplinaController;
import aula10.ex1.controller.NotaController;
import aula10.ex1.controller.TipoDeProvaController;
import aula10.ex1.model.BoletimModel;
import aula10.ex1.view.JanelaPrincipal;

/**
 * 
 * Ponto de entrada: cria o MODELO, a VISÃO e as CONTROLADORAS e "costura" as três partes.
 *
 *   VISÃO  --observa-->  MODELO   (a tela se atualiza quando o modelo muda)
 *   CONTROLADORA  liga os eventos da VISÃO às operações do MODELO
 *   
 */

public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignorada) {
                // usa o visual padrão do Swing
            }

            BoletimModel modelo = new BoletimModel();
            JanelaPrincipal janela = new JanelaPrincipal();

            // A interface gráfica OBSERVA o modelo
            modelo.addPropertyChangeListener(janela.getPainelAlunos());
            modelo.addPropertyChangeListener(janela.getPainelDisciplinas());
            modelo.addPropertyChangeListener(janela.getPainelTiposDeProva());
            modelo.addPropertyChangeListener(janela.getPainelNotas());

            // As controladoras ligam visão e modelo
            new AlunoController(modelo, janela.getPainelAlunos());
            new DisciplinaController(modelo, janela.getPainelDisciplinas());
            new TipoDeProvaController(modelo, janela.getPainelTiposDeProva());
            new NotaController(modelo, janela.getPainelNotas());

            janela.setVisible(true);

            try {
                modelo.carregarTudo();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(janela,
                        "Não foi possível conectar ao banco de dados.\n"
                        + "Verifique se o MariaDB está ativo, se os scripts SQL foram executados\n"
                        + "e se o driver JDBC está na pasta lib.\n\n"
                        + ex.getMessage(),
                        "Erro de conexão", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
