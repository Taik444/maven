package aula10.ex1.controller;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import aula10.ex1.model.BoletimModel;
import aula10.ex1.model.TipoDeProva;
import aula10.ex1.view.PainelTiposDeProva;

/**
 * 
 * CONTROLADORA - trata os eventos da tela de tipo de prova (cliques nos
 * botões) e decide quem deve agir: pede ao MODELO para gravar/excluir e
 * pede à VISÃO para limpar o formulário ou exibir mensagens.
 * 
 */

public class TipoDeProvaController {

    private final BoletimModel modelo;
    private final PainelTiposDeProva visao;

    public TipoDeProvaController(BoletimModel modelo, PainelTiposDeProva visao) {
        this.modelo = modelo;
        this.visao = visao;

        visao.addCadastrarListener(e -> cadastrar());
        visao.addAtualizarListener(e -> atualizar());
        visao.addExcluirListener(e -> excluir());

        // Associa a ação de desselecionar ao método de limpar formulário
        visao.addDesselecionarListener(e -> visao.limparFormulario());
    }

    // Apenas INSERE um novo registro (força id_tipo_de_prova = 0)
    private void cadastrar() {
    	int id_tipo_de_prova = visao.getIdEmEdicao();
        if (id_tipo_de_prova != 0) {
            visao.mostrarAviso("Para atualizar um tipo de prova já existente, clique no botão 'Atualizar'.");
            return;
        }

        try {

            TipoDeProva t = new TipoDeProva(0, visao.getNome());
            modelo.salvarTipoDeProva(t);
            visao.limparFormulario();

        } catch (IllegalArgumentException ex) {

            visao.mostrarAviso(ex.getMessage());

        } catch (SQLIntegrityConstraintViolationException ex) {

            visao.mostrarAviso("Já existe um tipo de prova com esse nome.");

        } catch (SQLException ex) {

            visao.mostrarErro("Erro no banco de dados: " + ex.getMessage());

        }
    }

    private void atualizar() {

    	int id_tipo_de_prova = visao.getIdEmEdicao();

        if (id_tipo_de_prova == 0) {
            visao.mostrarAviso("Para inserir um novo tipo de prova, clique no botão 'Cadastrar'.");
            return;
        }

        try {

            TipoDeProva t = new TipoDeProva(visao.getIdEmEdicao(), visao.getNome());
            modelo.salvarTipoDeProva(t);
            visao.limparFormulario();

        } catch (IllegalArgumentException ex) {          // regra de negócio violada

            visao.mostrarAviso(ex.getMessage());

        } catch (SQLIntegrityConstraintViolationException ex) {

            visao.mostrarAviso("Já existe um tipo de prova com esse nome.");

        } catch (SQLException ex) {

            visao.mostrarErro("Erro no banco de dados: " + ex.getMessage());

        }
    }

    private void excluir() {
        int id = visao.getIdEmEdicao();

        if (id == 0) {
            visao.mostrarAviso("Selecione um tipo de prova na tabela para excluir.");
            return;
        }

        if (!visao.confirmar("Deseja realmente excluir o tipo de prova selecionado?")) {
            return;
        }

        try {

            modelo.excluirTipoDeProva(id);
            visao.limparFormulario();

        } catch (SQLIntegrityConstraintViolationException ex) {

            visao.mostrarAviso("Este tipo de prova possui notas lançadas e não pode ser excluído.");

        } catch (SQLException ex) {

            visao.mostrarErro("Erro no banco de dados: " + ex.getMessage());

        }
    }
}
