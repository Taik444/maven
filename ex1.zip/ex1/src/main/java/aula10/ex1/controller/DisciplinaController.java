package aula10.ex1.controller;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import aula10.ex1.model.BoletimModel;
import aula10.ex1.model.Disciplina;
import aula10.ex1.view.PainelDisciplinas;

/**
 * 
 * CONTROLADORA - trata os eventos da tela de disciplina (cliques nos
 * botões) e decide quem deve agir: pede ao MODELO para gravar/excluir e
 * pede à VISÃO para limpar o formulário ou exibir mensagens.
 * 
 */

public class DisciplinaController {

    private final BoletimModel modelo;
    private final PainelDisciplinas visao;

    public DisciplinaController(BoletimModel modelo, PainelDisciplinas visao) {
        this.modelo = modelo;
        this.visao = visao;

        visao.addCadastrarListener(e -> cadastrar());
        visao.addAtualizarListener(e -> atualizar());
        visao.addExcluirListener(e -> excluir());

        // Associa a ação de desselecionar ao método de limpar formulário
        visao.addDesselecionarListener(e -> visao.limparFormulario());
    }

    // Apenas INSERE um novo registro (força id_disciplina = 0)
    private void cadastrar() {
    	int id_disciplina = visao.getIdEmEdicao();
        if (id_disciplina != 0) {
            visao.mostrarAviso("Para atualizar uma disciplina já existente, clique no botão 'Atualizar'.");
            return;
        }

        try {

            Disciplina d = new Disciplina(0, visao.getNome());
            modelo.salvarDisciplina(d);
            visao.limparFormulario();

        } catch (IllegalArgumentException ex) {

            visao.mostrarAviso(ex.getMessage());

        } catch (SQLIntegrityConstraintViolationException ex) {

            visao.mostrarAviso("Já existe uma disciplina com esse nome.");

        } catch (SQLException ex) {

            visao.mostrarErro("Erro no banco de dados: " + ex.getMessage());

        }
    }

    private void atualizar() {

    	int id_disciplina = visao.getIdEmEdicao();

        if (id_disciplina == 0) {
            visao.mostrarAviso("Para inserir uma nova disciplina, clique no botão 'Cadastrar'.");
            return;
        }

        try {

            Disciplina d = new Disciplina(visao.getIdEmEdicao(), visao.getNome());
            modelo.salvarDisciplina(d);
            visao.limparFormulario();

        } catch (IllegalArgumentException ex) {          // regra de negócio violada

            visao.mostrarAviso(ex.getMessage());

        } catch (SQLIntegrityConstraintViolationException ex) {

            visao.mostrarAviso("Já existe uma disciplina com esse nome.");

        } catch (SQLException ex) {

            visao.mostrarErro("Erro no banco de dados: " + ex.getMessage());

        }
    }

    private void excluir() {
        int id = visao.getIdEmEdicao();

        if (id == 0) {
            visao.mostrarAviso("Selecione uma disciplina na tabela para excluir.");
            return;
        }

        if (!visao.confirmar("Deseja realmente excluir a disciplina selecionada?")) {
            return;
        }

        try {

            modelo.excluirDisciplina(id);
            visao.limparFormulario();

        } catch (SQLIntegrityConstraintViolationException ex) {

            visao.mostrarAviso("Esta disciplina possui notas lançadas e não pode ser excluída.");

        } catch (SQLException ex) {

            visao.mostrarErro("Erro no banco de dados: " + ex.getMessage());

        }
    }
}
