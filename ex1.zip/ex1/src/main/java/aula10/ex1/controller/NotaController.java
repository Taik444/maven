package aula10.ex1.controller;

import aula10.ex1.model.Aluno;
import aula10.ex1.model.BoletimModel;
import aula10.ex1.model.Disciplina;
import aula10.ex1.model.Nota;
import aula10.ex1.model.TipoDeProva;
import aula10.ex1.view.PainelNotas;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

/**
 * 
 * CONTROLADORA - trata os eventos da tela de nota (cliques nos
 * botões) e decide quem deve agir: pede ao MODELO para gravar/excluir e
 * pede à VISÃO para limpar o formulário ou exibir mensagens.
 * 
 */

public class NotaController {

    private final BoletimModel modelo;
    private final PainelNotas visao;

    public NotaController(BoletimModel modelo, PainelNotas visao) {
        this.modelo = modelo;
        this.visao = visao;

        this.visao.addCadastrarListener(e -> cadastrar());
        this.visao.addAtualizarListener(e -> atualizar());
        this.visao.addExcluirListener(e -> excluir());

        // Associa a ação de desselecionar ao método de limpar formulário
        this.visao.addDesselecionarListener(e -> visao.limparFormulario());
    }

    // Apenas insere novas notas
    private void cadastrar() {
    	int id_nota = visao.getIdEmEdicao();
        if (id_nota != 0) {
            visao.mostrarAviso("Para atualizar uma nota já existente, clique no botão 'Atualizar'.");
            return;
        }
        salvar(0); // Passa ID 0 para forçar criação
    }

    // Apenas atualiza notas existentes
    private void atualizar() {
        int id_nota = visao.getIdEmEdicao();
        if (id_nota == 0) {
            visao.mostrarAviso("Para inserir uma nova nota, clique no botão 'Cadastrar'.");
            return;
        }
        salvar(id_nota);
    }

    private void salvar(int id_nota) {
        try {
            Disciplina disciplina = visao.getDisciplinaSelecionada();
            TipoDeProva tipoDeProva = visao.getTipoDeProvaSelecionado();
            Aluno aluno = visao.getAlunoSelecionado();
            String notaStr = visao.getNotaDigitada().replace(",", ".").trim();

            // Bloqueia caso o aviso "Selecione..." esteja ativo
            if (disciplina == null || disciplina.getIdDisciplina() == 0) {
                visao.mostrarAviso("Por favor, selecione uma disciplina válida.");
                return;
            }
            if (tipoDeProva == null || tipoDeProva.getIdTipoDeProva() == 0) {
                visao.mostrarAviso("Por favor, selecione um tipo de prova válido.");
                return;
            }
            if (aluno == null || aluno.getIdAluno() == 0) {
                visao.mostrarAviso("Por favor, selecione um aluno válido.");
                return;
            }

            if (notaStr.isEmpty()) {
                visao.mostrarAviso("Preencha todos os campos do formulário.");
                return;
            }

            BigDecimal nota = new BigDecimal(notaStr);

            Nota n = new Nota(id_nota, disciplina, tipoDeProva, aluno, nota);

            modelo.salvarNota(n);
            visao.limparFormulario();

        } catch (NumberFormatException ex) {
            visao.mostrarAviso("A nota deve conter um valor numérico válido.");
        } catch (IllegalArgumentException ex) {
            visao.mostrarAviso(ex.getMessage());
        } catch (SQLIntegrityConstraintViolationException ex) {
            visao.mostrarAviso("Erro de integridade no banco de dados.");
        } catch (SQLException ex) {
            visao.mostrarErro("Erro no banco de dados: " + ex.getMessage());
        }
    }

    private void excluir() {
        int id = visao.getIdEmEdicao();
        if (id == 0) {
            visao.mostrarAviso("Selecione uma nota na tabela para excluir.");
            return;
        }
        if (!visao.confirmar("Deseja realmente excluir a nota selecionada?")) {
            return;
        }
        try {
            modelo.excluirNota(id);
            visao.limparFormulario();
        } catch (SQLException ex) {
            visao.mostrarErro("Erro no banco de dados: " + ex.getMessage());
        }
    }
}
