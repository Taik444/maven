package aula10.ex1.controller;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import aula10.ex1.model.Aluno;
import aula10.ex1.model.BoletimModel;
import aula10.ex1.view.PainelAlunos;

/**
 * 
 * CONTROLADORA - trata os eventos da tela de aluno (cliques nos
 * botões) e decide quem deve agir: pede ao MODELO para gravar/excluir e
 * pede à VISÃO para limpar o formulário ou exibir mensagens.
 * 
 */

public class AlunoController {

    private final BoletimModel modelo;
    private final PainelAlunos visao;

    public AlunoController(BoletimModel modelo, PainelAlunos visao) {
        this.modelo = modelo;
        this.visao = visao;

        visao.addCadastrarListener(e -> cadastrar());
        visao.addAtualizarListener(e -> atualizar());
        visao.addExcluirListener(e -> excluir());

        // Associa a ação de desselecionar ao método de limpar formulário
        visao.addDesselecionarListener(e -> visao.limparFormulario());
    }

    // Apenas INSERE um novo registro (força id_aluno = 0)
    private void cadastrar() {
    	int id_aluno = visao.getIdEmEdicao();
        if (id_aluno != 0) {
            visao.mostrarAviso("Para atualizar um aluno já existente, clique no botão 'Atualizar'.");
            return;
        }

        try {

            Aluno a = new Aluno(0, visao.getNome());
            modelo.salvarAluno(a);
            visao.limparFormulario();

        } catch (IllegalArgumentException ex) {

            visao.mostrarAviso(ex.getMessage());

        } catch (SQLIntegrityConstraintViolationException ex) {

            visao.mostrarAviso("Já existe um aluno com esse nome.");

        } catch (SQLException ex) {

            visao.mostrarErro("Erro no banco de dados: " + ex.getMessage());

        }
    }

    private void atualizar() {

    	int id_aluno = visao.getIdEmEdicao();

        if (id_aluno == 0) {
            visao.mostrarAviso("Para inserir um novo aluno, clique no botão 'Cadastrar'.");
            return;
        }

        try {

            Aluno a = new Aluno(visao.getIdEmEdicao(), visao.getNome());
            modelo.salvarAluno(a);
            visao.limparFormulario();

        } catch (IllegalArgumentException ex) {          // regra de negócio violada

            visao.mostrarAviso(ex.getMessage());

        } catch (SQLIntegrityConstraintViolationException ex) {

            visao.mostrarAviso("Já existe um aluno com esse nome.");

        } catch (SQLException ex) {

            visao.mostrarErro("Erro no banco de dados: " + ex.getMessage());

        }
    }

    private void excluir() {
        int id = visao.getIdEmEdicao();

        if (id == 0) {
            visao.mostrarAviso("Selecione um aluno na tabela para excluir.");
            return;
        }

        if (!visao.confirmar("Deseja realmente excluir o aluno selecionado?")) {
            return;
        }

        try {

            modelo.excluirAluno(id);
            visao.limparFormulario();

        } catch (SQLIntegrityConstraintViolationException ex) {

            visao.mostrarAviso("Este aluno possui notas lançadas e não pode ser excluído.");

        } catch (SQLException ex) {

            visao.mostrarErro("Erro no banco de dados: " + ex.getMessage());

        }
    }
}
