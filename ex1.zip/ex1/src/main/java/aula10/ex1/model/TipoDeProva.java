package aula10.ex1.model;

/**
 * 
 * MODELO - entidade que representa uma linha da tabela "tipos_de_prova"
 * (ex.: P1, P2, Substitutiva, Exame).
 * 
 */

public class TipoDeProva {

    private int id_tipo_de_prova;          // 0 = ainda não gravado no banco
    private String tipo_de_prova;

    public TipoDeProva(int id_tipo_de_prova, String tipo_de_prova) {
        this.id_tipo_de_prova = id_tipo_de_prova;
        this.tipo_de_prova = tipo_de_prova;
    }

    public int getIdTipoDeProva() { return id_tipo_de_prova; }
    public void setIdTipoDeProva(int id_tipo_de_prova) { this.id_tipo_de_prova = id_tipo_de_prova; }

    public String getTipoDeProva() { return tipo_de_prova; }
    public void setTipoDeProva(String tipo_de_prova) { this.tipo_de_prova = tipo_de_prova; }

    /** Usado pelo JComboBox para exibir o nome do tipo de prova. */
    @Override
    public String toString() {
        return tipo_de_prova;
    }
}
