package aula10.ex1.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * MODELO - acesso à tabela "notas" (padrão DAO).
 * A consulta faz JOIN com disciplinas, tipos_de_prova e alunos para trazer
 * os nomes já prontos para exibição na tabela da tela.
 * 
 */

public class NotaDAO implements INotaDAO {

    public List<Nota> Consultar() throws SQLException {

        String sql = "SELECT n.id_nota, n.nota, "
                   + "d.id_disciplina AS id_disciplina, d.disciplina AS disciplina, "
                   + "t.id_tipo_de_prova AS id_tipo_de_prova, t.tipo_de_prova AS tipo_de_prova, "
                   + "a.id_aluno AS id_aluno, a.nome_do_aluno AS nome_do_aluno "
                   + "FROM notas n "
                   + "JOIN disciplinas d ON d.id_disciplina = n.id_disciplina "
                   + "JOIN tipos_de_prova t ON t.id_tipo_de_prova = n.id_tipo_de_prova "
                   + "JOIN alunos a ON a.id_aluno = n.id_aluno "
                   + "ORDER BY n.id_nota";
        List<Nota> lista = new ArrayList<>();

        try (Connection con = ConexaoDB.getConnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Disciplina disciplina = new Disciplina(rs.getInt("id_disciplina"), rs.getString("disciplina"));
                TipoDeProva tipoDeProva = new TipoDeProva(rs.getInt("id_tipo_de_prova"), rs.getString("tipo_de_prova"));
                Aluno aluno = new Aluno(rs.getInt("id_aluno"), rs.getString("nome_do_aluno"));
                lista.add(new Nota(rs.getInt("id_nota"), disciplina, tipoDeProva, aluno, rs.getBigDecimal("nota")));
            }

        }

        return lista;

    }

    public void Cadastrar(Nota n) throws SQLException {

        String sql = "INSERT INTO notas (id_disciplina, id_tipo_de_prova, id_aluno, nota) VALUES (?, ?, ?, ?)";

        try (Connection con = ConexaoDB.getConnection(); PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

        	ps.setInt(1, n.getDisciplina().getIdDisciplina());
            ps.setInt(2, n.getTipoDeProva().getIdTipoDeProva());
            ps.setInt(3, n.getAluno().getIdAluno());
            ps.setBigDecimal(4, n.getNota());
            ps.executeUpdate();

            try (ResultSet chaves = ps.getGeneratedKeys()) {
                if (chaves.next()) {
                    n.setIdNota(chaves.getInt(1));
                }
            }
        }
    }

    public void Atualizar(Nota n) throws SQLException {
        String sql = "UPDATE notas SET id_disciplina = ?, id_tipo_de_prova = ?, id_aluno = ?, nota = ? WHERE id_nota = ?";
        try (Connection con = ConexaoDB.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, n.getDisciplina().getIdDisciplina());
            ps.setInt(2, n.getTipoDeProva().getIdTipoDeProva());
            ps.setInt(3, n.getAluno().getIdAluno());
            ps.setBigDecimal(4, n.getNota());
            ps.setInt(5, n.getIdNota());
            ps.executeUpdate();

        }
    }

    public void Excluir(int id) throws SQLException {
        String sql = "DELETE FROM notas WHERE id_nota = ?";
        try (Connection con = ConexaoDB.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        }
    }
}
