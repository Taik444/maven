package aula10.ex1.model;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 
 * MODELO (fachada do modelo) - guarda os dados da aplicação, aplica as
 * regras de negócio e AVISA os observadores quando algo muda.
 *
 * Esta classe NÃO conhece a visão nem os controladores: ela só dispara
 * eventos (PropertyChangeEvent). Quem quiser saber das mudanças (a
 * interface gráfica) se registra como observador - é o que o slide chama
 * de "a interface gráfica é uma OBSERVADORA do modelo".
 * 
 */

public class BoletimModel {

    public static final String ALUNOS = "alunos";
    public static final String DISCIPLINAS = "disciplinas";
    public static final String TIPOS_DE_PROVA = "tiposDeProva";
    public static final String NOTAS = "notas";

    private final PropertyChangeSupport observadores = new PropertyChangeSupport(this);
    private final IAlunoDAO alunoDAO = new AlunoDAO();
    private final IDisciplinaDAO disciplinaDAO = new DisciplinaDAO();
    private final ITipoDeProvaDAO tipoDeProvaDAO = new TipoDeProvaDAO();
    private final INotaDAO notaDAO = new NotaDAO();

    private List<Aluno> alunos = new ArrayList<>();
    private List<Disciplina> disciplinas = new ArrayList<>();
    private List<TipoDeProva> tiposDeProva = new ArrayList<>();
    private List<Nota> notas = new ArrayList<>();

    // ------------------------------------------------------------ observadores
    public void addPropertyChangeListener(PropertyChangeListener l) {
        observadores.addPropertyChangeListener(l);
    }

    // ------------------------------------------------------------ consultas
    public List<Aluno> getAlunos() {
        return Collections.unmodifiableList(alunos);
    }

    public List<Disciplina> getDisciplinas() {
        return Collections.unmodifiableList(disciplinas);
    }

    public List<TipoDeProva> getTiposDeProva() {
        return Collections.unmodifiableList(tiposDeProva);
    }

    public List<Nota> getNotas() {
        return Collections.unmodifiableList(notas);
    }

    // ------------------------------------------------------------ carga
    public void carregarTudo() throws SQLException {
        carregarAlunos();
        carregarDisciplinas();
        carregarTiposDeProva();
        carregarNotas();
    }

    public void carregarAlunos() throws SQLException {
        alunos = alunoDAO.Consultar();
        // old = null para garantir que o evento sempre seja disparado
        observadores.firePropertyChange(ALUNOS, null, getAlunos());
    }

    public void carregarDisciplinas() throws SQLException {
        disciplinas = disciplinaDAO.Consultar();
        observadores.firePropertyChange(DISCIPLINAS, null, getDisciplinas());
    }

    public void carregarTiposDeProva() throws SQLException {
        tiposDeProva = tipoDeProvaDAO.Consultar();
        observadores.firePropertyChange(TIPOS_DE_PROVA, null, getTiposDeProva());
    }

    public void carregarNotas() throws SQLException {
        notas = notaDAO.Consultar();
        observadores.firePropertyChange(NOTAS, null, getNotas());
    }

    // ------------------------------------------------------------ alunos
    public void salvarAluno(Aluno aluno) throws SQLException {

        if (aluno.getNomeDoAluno() == null || aluno.getNomeDoAluno().trim().isEmpty()) {
            throw new IllegalArgumentException("O nome do aluno é obrigatório.");
        }

        if (aluno.getNomeDoAluno().trim().length() > 120) {
            throw new IllegalArgumentException("O nome do aluno deve ter no máximo 120 caracteres.");
        }

        aluno.setNomeDoAluno(aluno.getNomeDoAluno().trim());

        if (aluno.getIdAluno() == 0) {
            alunoDAO.Cadastrar(aluno);
        } else {
            alunoDAO.Atualizar(aluno);
        }

        // O nome do aluno aparece na lista de notas (JOIN): recarrega tudo.
        carregarTudo();
    }

    public void excluirAluno(int idAluno) throws SQLException {
        alunoDAO.Excluir(idAluno);   // falha se houver notas (FK RESTRICT)
        carregarTudo();
    }

    // ------------------------------------------------------------ disciplinas
    public void salvarDisciplina(Disciplina disciplina) throws SQLException {

        if (disciplina.getDisciplina() == null || disciplina.getDisciplina().trim().isEmpty()) {
            throw new IllegalArgumentException("O nome da disciplina é obrigatório.");
        }

        if (disciplina.getDisciplina().trim().length() > 80) {
            throw new IllegalArgumentException("O nome da disciplina deve ter no máximo 80 caracteres.");
        }

        disciplina.setDisciplina(disciplina.getDisciplina().trim());

        if (disciplina.getIdDisciplina() == 0) {
            disciplinaDAO.Cadastrar(disciplina);
        } else {
            disciplinaDAO.Atualizar(disciplina);
        }

        // O nome da disciplina aparece na lista de notas (JOIN): recarrega tudo.
        carregarTudo();
    }

    public void excluirDisciplina(int idDisciplina) throws SQLException {
        disciplinaDAO.Excluir(idDisciplina);   // falha se houver notas (FK RESTRICT)
        carregarTudo();
    }

    // ------------------------------------------------------------ tipos de prova
    public void salvarTipoDeProva(TipoDeProva tipoDeProva) throws SQLException {

        if (tipoDeProva.getTipoDeProva() == null || tipoDeProva.getTipoDeProva().trim().isEmpty()) {
            throw new IllegalArgumentException("O nome do tipo de prova é obrigatório.");
        }

        if (tipoDeProva.getTipoDeProva().trim().length() > 40) {
            throw new IllegalArgumentException("O nome do tipo de prova deve ter no máximo 40 caracteres.");
        }

        tipoDeProva.setTipoDeProva(tipoDeProva.getTipoDeProva().trim());

        if (tipoDeProva.getIdTipoDeProva() == 0) {
            tipoDeProvaDAO.Cadastrar(tipoDeProva);
        } else {
            tipoDeProvaDAO.Atualizar(tipoDeProva);
        }

        // O nome do tipo de prova aparece na lista de notas (JOIN): recarrega tudo.
        carregarTudo();
    }

    public void excluirTipoDeProva(int idTipoDeProva) throws SQLException {
        tipoDeProvaDAO.Excluir(idTipoDeProva);   // falha se houver notas (FK RESTRICT)
        carregarTudo();
    }

    // ------------------------------------------------------------ notas
    public void salvarNota(Nota nota) throws SQLException {
        if (nota.getDisciplina() == null || nota.getDisciplina().getIdDisciplina() == 0) {
            throw new IllegalArgumentException("Selecione uma disciplina.");
        }
        if (nota.getTipoDeProva() == null || nota.getTipoDeProva().getIdTipoDeProva() == 0) {
            throw new IllegalArgumentException("Selecione um tipo de prova.");
        }
        if (nota.getAluno() == null || nota.getAluno().getIdAluno() == 0) {
            throw new IllegalArgumentException("Selecione um aluno.");
        }
        if (nota.getNota() == null
                || nota.getNota().compareTo(BigDecimal.ZERO) < 0
                || nota.getNota().compareTo(BigDecimal.TEN) > 0) {
            throw new IllegalArgumentException("A nota deve estar entre 0 e 10.");
        }

        if (nota.getIdNota() == 0) {
            notaDAO.Cadastrar(nota);
        } else {
            notaDAO.Atualizar(nota);
        }
        carregarNotas();
    }

    public void excluirNota(int id) throws SQLException {
        notaDAO.Excluir(id);
        carregarNotas();
    }
}
