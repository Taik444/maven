package aula10.ex1.model;

/**
 * 
 * MODELO - entidade que representa uma linha da tabela "alunos".
 * 
 */

public class Aluno {

    private int id_aluno;          // 0 = ainda não gravado no banco
    private String nome_do_aluno;

    public Aluno(int id_aluno, String nome_do_aluno) {
        this.id_aluno = id_aluno;
        this.nome_do_aluno = nome_do_aluno;
    }

    public int getIdAluno() { return id_aluno; }
    public void setIdAluno(int id_aluno) { this.id_aluno = id_aluno; }

    public String getNomeDoAluno() { return nome_do_aluno; }
    public void setNomeDoAluno(String nome_do_aluno) { this.nome_do_aluno = nome_do_aluno; }

    /** Usado pelo JComboBox para exibir o nome do aluno. */
    @Override
    public String toString() {
        return nome_do_aluno;
    }
}
