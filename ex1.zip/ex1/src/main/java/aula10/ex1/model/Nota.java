package aula10.ex1.model;

import java.math.BigDecimal;

/**
 * 
 * MODELO - entidade que representa uma linha da tabela "notas".
 * Cada nota se relaciona a uma Disciplina, um TipoDeProva e um Aluno.
 * 
 */

public class Nota {

    private int id_nota;          // 0 = ainda não gravada no banco
    private Disciplina disciplina;
    private TipoDeProva tipoDeProva;
    private Aluno aluno;
    private BigDecimal nota;

    public Nota(int id_nota, Disciplina disciplina, TipoDeProva tipoDeProva, Aluno aluno, BigDecimal nota) {
        this.id_nota = id_nota;
        this.disciplina = disciplina;
        this.tipoDeProva = tipoDeProva;
        this.aluno = aluno;
        this.nota = nota;
    }

    public int getIdNota() { return id_nota; }
    public void setIdNota(int id_nota) { this.id_nota = id_nota; }

    public Disciplina getDisciplina() { return disciplina; }
    public void setDisciplina(Disciplina disciplina) { this.disciplina = disciplina; }

    public TipoDeProva getTipoDeProva() { return tipoDeProva; }
    public void setTipoDeProva(TipoDeProva tipoDeProva) { this.tipoDeProva = tipoDeProva; }

    public Aluno getAluno() { return aluno; }
    public void setAluno(Aluno aluno) { this.aluno = aluno; }

    public BigDecimal getNota() { return nota; }
    public void setNota(BigDecimal nota) { this.nota = nota; }
}
