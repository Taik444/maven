package aula10.ex1.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * MODELO - acesso à tabela "disciplinas" (padrão DAO).
 * Todos os comandos usam PreparedStatement (evita SQL Injection).
 * 
 */

public class DisciplinaDAO implements IDisciplinaDAO {

    public List<Disciplina> Consultar() throws SQLException {
        String sql = "SELECT id_disciplina, disciplina FROM disciplinas ORDER BY id_disciplina";
        List<Disciplina> lista = new ArrayList<>();

        try (Connection con = ConexaoDB.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery())
        {
        	while (rs.next()) {
                lista.add(new Disciplina(rs.getInt("id_disciplina"), rs.getString("disciplina")));
            }

        }

        return lista;

    }

    public void Cadastrar(Disciplina disciplina) throws SQLException {
        String sql = "INSERT INTO disciplinas (disciplina) VALUES (?)";
        try (Connection con = ConexaoDB.getConnection(); PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, disciplina.getDisciplina());
            ps.executeUpdate();

            try (ResultSet chaves = ps.getGeneratedKeys()) {
                if (chaves.next()) {
                	disciplina.setIdDisciplina(chaves.getInt(1));
                }
            }

        }
    }

    public void Atualizar(Disciplina disciplina) throws SQLException {
        String sql = "UPDATE disciplinas SET disciplina = ? WHERE id_disciplina = ?";
        try (Connection con = ConexaoDB.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, disciplina.getDisciplina());
            ps.setInt(2, disciplina.getIdDisciplina());
            ps.executeUpdate();

        }
    }

    public void Excluir(int idDisciplina) throws SQLException {
        String sql = "DELETE FROM disciplinas WHERE id_disciplina = ?";
        try (Connection con = ConexaoDB.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idDisciplina);
            ps.executeUpdate();

        }
    }
}
