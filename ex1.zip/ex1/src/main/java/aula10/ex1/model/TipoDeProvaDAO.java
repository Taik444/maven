package aula10.ex1.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * MODELO - acesso à tabela "tipos_de_prova" (padrão DAO).
 * Todos os comandos usam PreparedStatement (evita SQL Injection).
 * 
 */

public class TipoDeProvaDAO implements ITipoDeProvaDAO {

    public List<TipoDeProva> Consultar() throws SQLException {
        String sql = "SELECT id_tipo_de_prova, tipo_de_prova FROM tipos_de_prova ORDER BY id_tipo_de_prova";
        List<TipoDeProva> lista = new ArrayList<>();

        try (Connection con = ConexaoDB.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery())
        {
        	while (rs.next()) {
                lista.add(new TipoDeProva(rs.getInt("id_tipo_de_prova"), rs.getString("tipo_de_prova")));
            }

        }

        return lista;

    }

    public void Cadastrar(TipoDeProva tipoDeProva) throws SQLException {
        String sql = "INSERT INTO tipos_de_prova (tipo_de_prova) VALUES (?)";
        try (Connection con = ConexaoDB.getConnection(); PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, tipoDeProva.getTipoDeProva());
            ps.executeUpdate();

            try (ResultSet chaves = ps.getGeneratedKeys()) {
                if (chaves.next()) {
                	tipoDeProva.setIdTipoDeProva(chaves.getInt(1));
                }
            }

        }
    }

    public void Atualizar(TipoDeProva tipoDeProva) throws SQLException {
        String sql = "UPDATE tipos_de_prova SET tipo_de_prova = ? WHERE id_tipo_de_prova = ?";
        try (Connection con = ConexaoDB.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, tipoDeProva.getTipoDeProva());
            ps.setInt(2, tipoDeProva.getIdTipoDeProva());
            ps.executeUpdate();

        }
    }

    public void Excluir(int idTipoDeProva) throws SQLException {
        String sql = "DELETE FROM tipos_de_prova WHERE id_tipo_de_prova = ?";
        try (Connection con = ConexaoDB.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idTipoDeProva);
            ps.executeUpdate();

        }
    }
}
