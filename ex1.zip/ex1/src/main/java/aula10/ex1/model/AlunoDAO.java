package aula10.ex1.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * MODELO - acesso à tabela "alunos" (padrão DAO).
 * Todos os comandos usam PreparedStatement (evita SQL Injection).
 * 
 */

public class AlunoDAO implements IAlunoDAO {

    public List<Aluno> Consultar() throws SQLException {
        String sql = "SELECT id_aluno, nome_do_aluno FROM alunos ORDER BY id_aluno";
        List<Aluno> lista = new ArrayList<>();

        try (Connection con = ConexaoDB.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery())
        {
        	while (rs.next()) {
                lista.add(new Aluno(rs.getInt("id_aluno"), rs.getString("nome_do_aluno")));
            }

        }

        return lista;

    }

    public void Cadastrar(Aluno aluno) throws SQLException {
        String sql = "INSERT INTO alunos (nome_do_aluno) VALUES (?)";
        try (Connection con = ConexaoDB.getConnection(); PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, aluno.getNomeDoAluno());
            ps.executeUpdate();

            try (ResultSet chaves = ps.getGeneratedKeys()) {
                if (chaves.next()) {
                	aluno.setIdAluno(chaves.getInt(1));
                }
            }

        }
    }

    public void Atualizar(Aluno aluno) throws SQLException {
        String sql = "UPDATE alunos SET nome_do_aluno = ? WHERE id_aluno = ?";
        try (Connection con = ConexaoDB.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, aluno.getNomeDoAluno());
            ps.setInt(2, aluno.getIdAluno());
            ps.executeUpdate();

        }
    }

    public void Excluir(int idAluno) throws SQLException {
        String sql = "DELETE FROM alunos WHERE id_aluno = ?";
        try (Connection con = ConexaoDB.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idAluno);
            ps.executeUpdate();

        }
    }
}
