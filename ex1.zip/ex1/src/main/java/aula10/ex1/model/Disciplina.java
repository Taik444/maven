package aula10.ex1.model;

/**
 * 
 * MODELO - entidade que representa uma linha da tabela "disciplinas".
 * 
 */

public class Disciplina {

    private int id_disciplina;          // 0 = ainda não gravada no banco
    private String disciplina;

    public Disciplina(int id_disciplina, String disciplina) {
        this.id_disciplina = id_disciplina;
        this.disciplina = disciplina;
    }

    public int getIdDisciplina() { return id_disciplina; }
    public void setIdDisciplina(int id_disciplina) { this.id_disciplina = id_disciplina; }

    public String getDisciplina() { return disciplina; }
    public void setDisciplina(String disciplina) { this.disciplina = disciplina; }

    /** Usado pelo JComboBox para exibir o nome da disciplina. */
    @Override
    public String toString() {
        return disciplina;
    }
}
