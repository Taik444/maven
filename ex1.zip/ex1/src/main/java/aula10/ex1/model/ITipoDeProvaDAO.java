package aula10.ex1.model;

import java.sql.SQLException;
import java.util.List;

/**
 * 
 * Interface para a classe TipoDeProvaDAO
 * 
 */

public interface ITipoDeProvaDAO {

    void Cadastrar(TipoDeProva tipoDeProva) throws SQLException;
    void Atualizar(TipoDeProva tipoDeProva) throws SQLException;
    void Excluir(int idTipoDeProva) throws SQLException;
    List<TipoDeProva> Consultar() throws SQLException;

}
