package aula10.ex1.model;

import java.sql.SQLException;
import java.util.List;

/**
 * 
 * Interface para a classe DisciplinaDAO
 * 
 */

public interface IDisciplinaDAO {

    void Cadastrar(Disciplina disciplina) throws SQLException;
    void Atualizar(Disciplina disciplina) throws SQLException;
    void Excluir(int idDisciplina) throws SQLException;
    List<Disciplina> Consultar() throws SQLException;

}
