package aula10.ex1.model;

import java.sql.SQLException;
import java.util.List;

/**
 * 
 * Interface para a classe NotaDAO
 * 
 */

public interface INotaDAO {

    void Cadastrar(Nota nota) throws SQLException;
    void Atualizar(Nota nota) throws SQLException;
    void Excluir(int idNota) throws SQLException;
    List<Nota> Consultar() throws SQLException;

}
