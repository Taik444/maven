package aula10.ex1.model;

import java.sql.SQLException;
import java.util.List;

/**
 * 
 * Interface para a classe AlunoDAO
 * 
 */

public interface IAlunoDAO {

    void Cadastrar(Aluno aluno) throws SQLException;
    void Atualizar(Aluno aluno) throws SQLException;
    void Excluir(int idAluno) throws SQLException;
    List<Aluno> Consultar() throws SQLException;

}
